# climate_change

This project concentrates on understanding climate change, how it has been changing and predicting the climate change

In this project we used the data from 1750 to 2015 (source: Kaggle) to perform analysis and prediction

project folder structure:

data_raw:  consists of raw data which is not cleaned

data_clean: holds the clean data

src: holds the code files used for cleaning, analysis and prediction

results: holds the results we obtained from analysis and prediction
